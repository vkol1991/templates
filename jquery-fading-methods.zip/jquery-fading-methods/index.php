<html>
<head>
<title>jQuery Fading Methods</title><script src="http://code.jquery.com/jquery-2.1.1.js"></script><style type="text/css" media="screen">	body{width:610;}	#menu{background: #D8F9D3;height: 40px;border-top: #F0F0F0 2px solid;}	#menu input[type="button"]{margin-left: 2px;padding: 0px 15px;height: 40px;border: 0px;background: #F0F0F0;}
	#output{min-height:150px;border:#F0F0F0 1px solid;padding:30px;}</style><script type="text/javascript">$(document).ready(function() {$("#fade-in").click(function() {  $( "#fading-photo" ).fadeIn("slow");});$("#fade-out").click(function() {  $( "#fading-photo" ).fadeOut("slow");});$("#fade-to").click(function() {  $( "#fading-photo" ).fadeTo("slow", 0.5);});$("#fade-toggle").click(function() {  $( "#fading-photo" ).fadeToggle("slow", "linear");});});</script>
</head>
<body><div id="menu"><input type="button" value="Fade In" id="fade-in" /><input type="button" value="Fade Out" id="fade-out" /><input type="button" value="Fade To" id="fade-to" /><input type="button" value="Fade Toggle" id="fade-toggle" />
</div><div id="output"><img src="fading-photo.png" id="fading-photo" /></div>
</body>
</html>
