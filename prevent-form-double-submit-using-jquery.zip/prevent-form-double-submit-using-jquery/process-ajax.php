<?php 
	if(!empty($_POST["title"])) {
		print "Title: " . $_POST["title"];
	}
?>